function playvid(vid)
{
    vid.play()
}
function pausevid(vid)
{
    vid.pause()
}